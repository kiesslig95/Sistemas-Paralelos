#include "mpi.h"
#include <stdio.h>

#define N 10000 // tamaño arreglo
#define Rango 104729 // rango primos

int primo(int n){  //retorna 0 cuando no es primo y 1 cuando es primo
    int i, res, mitad;
    i=2;
    res = n > 1;
    mitad =n/2;
    while (res!=0 && i<= mitad)
    {
        res= n%i;
        i++;
    }
    return res;
}

int main(int argc,char *argv[]) {
    int rank, sendcount, recvcount, root,i;
    int sendbuf[N];
    int size,*sendbuf;
    float recvbuf[4];
    int arreglo[N];
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) {
        sendbuf = (int*)malloc(N);
        root = 0;
        sendcount = N; 
        recvcount = N;
    }

     
    MPI_Scatter(
        sendbuf, /* es el buffer con los datos a repartir y solo tienen significado en el proceso root */
        sendcount, /* es la cantidad de elementos a enviar a cada proceso */
        MPI_FLOAT,
        recvbuf, /* es el buffer donde se recibirán los datos */
        recvcount, /* es la cantidad de elementos del buffer de recepción */
        MPI_FLOAT,
        root,/* root es el rank del proceso que tiene los datos a repartir */
        MPI_COMM_WORLD);

        for ( i = 0; i < recvcount; i++)
        {
            
        }
    
 MPI_Finalize();
}